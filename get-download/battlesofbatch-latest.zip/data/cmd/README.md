These files were made for development purposes, you are not supposed to use any of them.
Unexpected usage of these files might cause issues on your save files, or even corrupt the whole game.
