Copyright (C) 2019~2022 HTSoft-Studios™

Hey! Welcome.


 <(?)> INFORMATION <(?)>

- - - - About - - - -
<=> Contact (#1.0) <=>
 Discord: discord.gg/Qst63njdBG (for Community & Support)
 e-Mail: htsdevteamofficial@gmail.com (for Business)
 Website: htssoft.tk (for More Information)
<=> Copyright (#1.1 <=>
 Read: copyright.txt
- - - - - - - - - - -




 <(?)> - GAMEPLAY - <(?)>

- - - - Game Controls - - - -
<=> Key Words (#2.0) <=>
 Menu: "Play/Start = Level Selection", "Quests = Quests", "Shop = Workshop & Upgrades", "Settings/Options = Edit your Preferences" "Exit = Exit The Game"
 Map: "Play/Start" = Start Selected Level", "Forward = Move Forward/Next Level", "Prev = Move Backwards/Previous Level", "Exit/Back = Go Back"
 Battle: (Enter the Whole Words of an Action), "Exit/Quit/Back = Go Back"

<=> Shortcut Keys (#2.1) <=>
 Menu: "A/P" = Level Selection", "Q = Quests", "W = Workshop & Upgrades", "S = Settings/Options" "E = Exit The Game"
 Map: "A/P" = Start Selected Level", "F = Move Forward/Next Level", "D = Move Backwards/Previous Level", "Q = Go Back"
 Battle: (Press the First Letter of an Action), "Q = Go Back"
- - - - - - - - - - - - - - -

- - - - Strategy Method - - - -
<=> How it Works : Enemies (#3.0) <=>
 Enemies spawn with a random amount of HP.
 Enemies deal a random amount of damage to the player.
 Every enemy deals its own damage, so this means once one enemy is dead it will no longer deal damage, dealing less total damage to the player.

<=> How it Works : Skills (#3.1) <=>
 Main Attack: ?
 Crit Rate: ?
 Max Health: ?

<=> How it Works : Items (#3.2) <=>
 Bomb: Stuns enemies, skipping their next round/action. Bosses cannot be stunned by this attack type. Effects, such as poison on the player, will still function.
 Heal: Gives the player HP. This does not skip the next enemy round/action, and still take damage. Thus it's upgradable.
 More coming soon.

<=> How it Works : Materials (#3.3) <=>
 Coming soon.
- - - - - - - - - - - - - - - -


- - - - User Interfaces - - - -
<=> Shop (4.0) <=>
 Items: Items require in-game currency and specific character level. The level requirement is replaced by the symbol "↑", and currency by the symbol "$".
 Skills: ?

<=> Quests (4.1) <=>
 ?

<=> Options (4.2) <=>
 ?
- - - - - - - - - - - - - - - -


- - - - Map Levels Strategy - - - -
 1: Find out!
 2: Find out!
 3: Find out!
 4: Find out!
 5: Find out!
 6: Find out!
 7: Find out!
- - - - - - - - - - - - - - - - - -