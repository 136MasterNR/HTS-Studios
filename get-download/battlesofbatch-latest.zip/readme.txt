This product is not yet released and still in a testing stage. If you are tester, please follow the instructions which were given to you.


To get back your saved data, go in the old directroy, copy the saves and paste them into the new directory.
Saving Directory: %Appdata%\HTS_DATA\ ...