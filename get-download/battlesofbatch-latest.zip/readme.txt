This product is not yet released and still in a testing stage. If you are tester, please follow the instructions which were given to you.


To get back your saved data, go in the old directroy, take the saves and place them into the new directory.
Saving Directory: %Appdata%\HTS-DATA\ ...
This process will be automatic when auto updating.