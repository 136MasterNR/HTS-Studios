$key = $Host.UI.RawUI.ReadKey()
if ($key.Character -eq '1') {
  "Pressed 1"
}
$key = $Host.UI.RawUI.ReadKey()